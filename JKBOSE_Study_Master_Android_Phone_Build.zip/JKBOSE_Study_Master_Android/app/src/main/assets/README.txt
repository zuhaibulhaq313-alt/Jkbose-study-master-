JKBOSE STUDY MASTER — VERSION 4: EXPANDED QUIZ BANK

App name: JKBOSE Study Master
Icon: Open book
Audience: Classes 9–12 and UPSC foundation
Language: English

FILES
- index.html: home dashboard
- quizzes.html: Quiz Centre with class/subject/topic filters and expanded topic banks
- quiz.html: separate 50-question Class 11 Political Science quiz
- manifest.json: PWA metadata
- sw.js: basic offline cache
- icon.svg: open-book icon

WHAT'S NEW
- 120 additional multiple-choice questions across 12 topic sets.
- Existing Quiz Centre starter questions retained.
- Existing 50-question Class 11 Political Science quiz retained.
- Instant feedback, explanations, scores, and incorrect-answer review.
- Filter quizzes by class/level, subject, and topic.

HOW TO TEST
1. Extract this ZIP.
2. Open index.html in a modern browser.
3. Select “Open Quiz Centre”.
4. Filter by class, subject or topic and start a quiz.
5. The standalone 50-question Political Science quiz is available from the dashboard.
6. For installable PWA testing, host the folder on HTTPS or run a local web server; service workers generally do not work when opened as file://.

CONTENT NOTICE
This is a starter bank, not a complete syllabus-aligned question bank or a guarantee of exam predictions. Review each item and verify content against the latest JKBOSE syllabus and prescribed textbooks before relying on it for exam preparation.

IMPORTANT
This is a web-app prototype, not a compiled Android APK or Play Store release. Android packaging, device testing, content verification, privacy/accessibility review and signing remain to be done.
