plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jkbose.studymaster"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jkbose.studymaster"
        minSdk = 23
        targetSdk = 35
        versionCode = 4
        versionName = "4.0"
    }
}
