JKBOSE Study Master — Android Studio project (Version 4.0)

WHAT'S INCLUDED
- Android app wrapper named JKBOSE Study Master
- Bundled offline HTML assets from the V4 prototype
- Quiz Centre with 150 added MCQs across 15 topic sets, plus existing starter sets
- Standalone Class 11 Political Science 50-question quiz
- App uses a WebView to show bundled content without needing internet during quizzes

IMPORTANT
This ZIP is the Android Studio project source, not a prebuilt APK. This workspace does not have the Android SDK/Gradle build environment installed, so an APK has not been compiled here. The question bank is a starter practice resource and is not an official JKBOSE publication; verify against the current syllabus/textbooks.

BUILD A DEBUG APK
1. On a computer, install Android Studio.
2. Extract this ZIP.
3. In Android Studio select Open and choose the extracted JKBOSE_Study_Master_Android folder.
4. Allow Gradle sync. Install Android SDK Platform 35 if Android Studio asks.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The APK is normally created at app/build/outputs/apk/debug/app-debug.apk.
7. Transfer that APK to your Android phone and install it. Android may ask you to permit installs from the app used to open the file.

PACKAGE DETAILS
Application ID: com.jkbose.studymaster
Version: 4.0
Minimum Android: Android 6.0 (API 23)

If you only have an Android phone and no computer, this project ZIP alone cannot be installed as an app; it must first be built into an APK using a compatible Android build environment.
